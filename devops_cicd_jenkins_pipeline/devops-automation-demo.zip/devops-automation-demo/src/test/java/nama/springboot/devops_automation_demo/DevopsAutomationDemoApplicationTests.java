package nama.springboot.devops_automation_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsAutomationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
